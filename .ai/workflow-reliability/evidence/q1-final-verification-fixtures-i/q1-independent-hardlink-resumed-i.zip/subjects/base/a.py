value = 1
# owned target edit
