import pathlib,sys
pathlib.Path(sys.argv[1]).write_text('executed')
sys.stdout.buffer.write(sys.stdin.buffer.read())
