from builtins import __import__ as load
import importlib as loader
load('a')
loader.reload(loader)
