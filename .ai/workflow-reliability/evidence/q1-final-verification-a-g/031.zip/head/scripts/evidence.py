import a
import imaginary_external
from importlib import import_module as load
load('a')
