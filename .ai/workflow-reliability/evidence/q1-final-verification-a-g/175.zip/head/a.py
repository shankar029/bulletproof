import fractions
from pkg import inner
