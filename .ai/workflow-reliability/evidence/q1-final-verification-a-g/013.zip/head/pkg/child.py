if True:
    import a

def f():
    from . import sibling
