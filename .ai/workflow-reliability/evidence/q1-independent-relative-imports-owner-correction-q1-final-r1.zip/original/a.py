from pkg.sub import child
VALUE = child.VALUE
