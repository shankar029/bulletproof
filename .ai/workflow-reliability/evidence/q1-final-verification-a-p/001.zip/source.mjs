export function eligible(n) { return n >= 2; }
