
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { eligible } from './source.mjs';
test('boundary', () => { assert.equal(eligible(1), false); assert.equal(eligible(2), true); });
